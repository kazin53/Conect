package com.ryque.pixlistener

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log

class PixNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val appPackage = sbn.packageName
        val title = extras.getString("android.title") ?: ""
        val content = extras.getCharSequence("android.text")?.toString() ?: ""

        if (content.contains("Pix", ignoreCase = true)) {
            Log.d("PixListener", "Notificação Pix detectada:")
            Log.d("PixListener", "App: $appPackage")
            Log.d("PixListener", "Título: $title")
            Log.d("PixListener", "Conteúdo: $content")
        }
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        Log.d("PixListener", "Serviço conectado")
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        Log.d("PixListener", "Serviço desconectado")
    }
}
